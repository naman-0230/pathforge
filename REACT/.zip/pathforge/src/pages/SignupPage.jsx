import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import Nav from '../components/Nav';
import Button from '../components/Button';
import '../styles/auth.css';

// SignupPage — converted from signup.html.
// Same pattern as LoginPage: three fields in state, form submit navigates to /onboarding
// (matching the original href="onboarding.html"), ready to be swapped for a real
// signup API call later.
export default function SignupPage() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();

  function handleSubmit(e) {
    e.preventDefault();
    // TODO: replace with real signup API call once backend exists.
    console.log('Signup attempt:', { name, email, password });
    navigate('/onboarding');
  }

  return (
    <>
      <Nav
        right={
          <>
            <span style={{ fontSize: 13, color: 'var(--text-mid)' }}>Already have an account?</span>
            <Link to="/login" className="btn btn-sm">Log in</Link>
          </>
        }
      />

      <div className="auth-wrap">
        <div className="auth-card">
          <div className="auth-header">
            <h1>Create your account</h1>
            <p>Start building your DSA roadmap in 2 minutes</p>
          </div>

          <form className="auth-form" onSubmit={handleSubmit}>
            <div className="field">
              <label htmlFor="name">Full name</label>
              <input
                type="text"
                id="name"
                placeholder="Rahul Sharma"
                value={name}
                onChange={(e) => setName(e.target.value)}
                required
              />
            </div>
            <div className="field">
              <label htmlFor="email">Email</label>
              <input
                type="email"
                id="email"
                placeholder="you@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </div>
            <div className="field">
              <label htmlFor="password">Password</label>
              <input
                type="password"
                id="password"
                placeholder="Min 8 characters"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                minLength={8}
                required
              />
            </div>
            <Button type="submit" variant="primary" className="auth-submit">
              Create account
            </Button>
            <p style={{ fontSize: 11, color: 'var(--text-low)', textAlign: 'center', marginTop: 4 }}>
              By signing up, you agree to our Terms and Privacy Policy.
            </p>
          </form>

          <div className="auth-divider"><span>or</span></div>

          <button className="btn auth-google">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
              <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
              <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
              <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z" fill="#FBBC05"/>
              <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
            </svg>
            Continue with Google
          </button>

          <p className="auth-footer">Already have an account? <Link to="/login">Log in</Link></p>
        </div>
      </div>
    </>
  );
}
